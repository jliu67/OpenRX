// SPDX-License-Identifier: BSD-3-Clause
// Diagnostic-only second top: passive reads of the unchanged testbench/public
// ports. This bounded observation produces PARTIAL evidence, never acceptance.
`timescale 1ns/1ps
module superscalar_progress_observer;
    integer progress_fd,cap=8192,settled_ticks=0,events,sample_case,sample_target;
    integer previous_run_ticks=0,step_calls=0;
    integer previous_aborts=-1,previous_completed=-1,previous_cases=-1;
    integer previous_case=-1,previous_target=-1,previous_phase=-1;
    reg previous_rst=1,previous_cancel=0,pre_rst,pre_cancel;
    string progress_path,mode;

    task emit;input integer flags;begin
        $fdisplay(progress_fd,
            "OBS superscalar_progress mode=%0s event_flags=%0d settled_ticks=%0d time_ns=%0d case=%0d target=%0d phase=%0d run_ticks=%0d step_calls=%0d aborts=%0d completed=%0d cases=%0d requests=%0d responses=%0d commits=%0d pending=%0d fetch_pc=%0d retired=%0d pre_rst=%0d pre_cancel=%0d",
            mode,flags,settled_ticks,$time,sample_case,
            sample_target,tb_superscalar_execute.phase,
            tb_superscalar_execute.run_ticks,step_calls,tb_superscalar_execute.aborts,
            tb_superscalar_execute.completed,tb_superscalar_execute.total_cases,
            tb_superscalar_execute.requests,tb_superscalar_execute.responses,
            tb_superscalar_execute.commits,tb_superscalar_execute.pending,
            tb_superscalar_execute.fetch_pc,tb_superscalar_execute.rsp_retired,
            pre_rst,pre_cancel);
        $fflush(progress_fd);
        // Existing result writes are buffered. Flush, without adding/changing
        // records, so a terminated partial probe preserves completed rows.
        if(tb_superscalar_execute.result_fd!=0)$fflush(tb_superscalar_execute.result_fd);
    end endtask

    initial begin
        if(!$value$plusargs("PROGRESS=%s",progress_path))$fatal(1,"diagnostic observer requires PROGRESS");
        if(!$value$plusargs("MODE=%s",mode)||(mode!="cancel"&&mode!="reset"))
            $fatal(1,"diagnostic observer requires cancel/reset mode");
        if($value$plusargs("DIAGNOSTIC_CYCLES=%d",cap))begin end
        if(cap!=8192&&cap!=16384)$fatal(1,"diagnostic cap must be 8192 or 16384");
        progress_fd=$fopen(progress_path,"w");
        if(!progress_fd)$fatal(1,"cannot create diagnostic progress file");
        $fdisplay(progress_fd,"BEGIN superscalar_progress mode=%0s cap=%0d acceptance=0",mode,cap);
        $fflush(progress_fd);
    end

    // The frozen bench performs its existing edge assertions by #1. Sample
    // after them at #2, before the next stimulus edge at +5. No bench/DUT
    // signal is driven, and reset/cancel never resets this global cap.
    always @(posedge tb_superscalar_execute.clk)begin
        pre_rst=tb_superscalar_execute.rst;pre_cancel=tb_superscalar_execute.cancel;
        #2;settled_ticks=settled_ticks+1;events=0;
        // run_ticks resets for each captured request; sum only its positive
        // deltas. This counts original step calls and excludes non-step idle
        // and control clocks, which remain in settled_ticks.
        if(tb_superscalar_execute.run_ticks>=previous_run_ticks)
            step_calls=step_calls+tb_superscalar_execute.run_ticks-previous_run_ticks;
        previous_run_ticks=tb_superscalar_execute.run_ticks;
        sample_case=tb_superscalar_execute.total_cases==0?-1:tb_superscalar_execute.case_id;
        sample_target=tb_superscalar_execute.total_cases==0?-1:tb_superscalar_execute.target;
        if(settled_ticks%1024==0)events=events|1;
        if(tb_superscalar_execute.total_cases!=previous_cases||sample_case!=previous_case)events=events|2;
        if(sample_target!=previous_target)events=events|4;
        if(tb_superscalar_execute.aborts!=previous_aborts)events=events|8;
        if(tb_superscalar_execute.completed!=previous_completed)events=events|16;
        if(tb_superscalar_execute.phase!=previous_phase&&
           tb_superscalar_execute.phase==tb_superscalar_execute.target&&
           tb_superscalar_execute.total_cases%2==1)events=events|32;
        if(pre_rst!=previous_rst||pre_cancel!=previous_cancel)events=events|64;
        if(tb_superscalar_execute.phase!=previous_phase&&tb_superscalar_execute.phase==6)events=events|128;
        if(settled_ticks==cap)events=events|256;
        if(events!=0)emit(events);
        previous_aborts=tb_superscalar_execute.aborts;previous_completed=tb_superscalar_execute.completed;
        previous_cases=tb_superscalar_execute.total_cases;previous_case=sample_case;
        previous_target=sample_target;previous_phase=tb_superscalar_execute.phase;
        previous_rst=pre_rst;previous_cancel=pre_cancel;
        if(settled_ticks==cap)begin
            $fdisplay(progress_fd,"DIAGNOSTIC_PARTIAL superscalar_execute mode=%0s settled_ticks=%0d cap=%0d time_ns=%0d run_ticks=%0d step_calls=%0d acceptance=0",mode,settled_ticks,cap,$time,tb_superscalar_execute.run_ticks,step_calls);
            $fflush(progress_fd);$fclose(progress_fd);
            $display("DIAGNOSTIC_PARTIAL superscalar_execute mode=%0s settled_ticks=%0d cap=%0d time_ns=%0d run_ticks=%0d step_calls=%0d acceptance=0",mode,settled_ticks,cap,$time,tb_superscalar_execute.run_ticks,step_calls);
            $finish;
        end
    end
endmodule
