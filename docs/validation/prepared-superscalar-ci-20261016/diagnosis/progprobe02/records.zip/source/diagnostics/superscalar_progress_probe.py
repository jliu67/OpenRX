#!/usr/bin/env python3
"""Bounded data-bound RESET-prefix observation; never a validation PASS.

Authoring does not execute this driver. Run only in a separately reviewed and
admitted payload. Two sequential arms use retained local/hosted netlists, their
own original cell models, the unchanged bench and identical native fixtures.
No native generation, synthesis, full-mode repeat or acceptance is performed.
"""
import argparse
import ctypes
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import signal
import subprocess
import time
import zipfile

ROOT = Path(__file__).resolve().parents[1]
BENCH = ROOT / 'rtl/execute/tests/tb_superscalar_execute.v'
OBSERVER = ROOT / 'diagnostics/superscalar_progress_observer.v'
BENCH_SHA = '33d7cc3396edf08f3a3e0827a5178ee18a366d19e9438e024e9dc60ea224fd24'
OBSERVER_SHA = '75c647fa86b3f559bd93bb392d3ad8eac1ae0648eda2e683a49ae6f51b0687fb'
CAP = 8192
WALL_SECONDS = 60
NETLIST = 'netlist-superscalar.v'
CELLS = 'yosys-simcells.v'


def sha(path):
    value = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            value.update(block)
    return value.hexdigest()


def load(path):
    return json.loads(path.read_text())


def save(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


def binding(path):
    assert path.is_file() and not path.is_symlink(), str(path)
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': sha(path)}


def source_head():
    return subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()


def process_group(pgid):
    """Snapshot only this newly created session/group; tolerate exit races."""
    members = []
    ticks = os.sysconf('SC_CLK_TCK')
    for directory in Path('/proc').iterdir():
        if not directory.name.isdigit():
            continue
        try:
            raw = (directory / 'stat').read_text()
            close = raw.rindex(')')
            fields = raw[close + 2:].split()
            if int(fields[2]) != pgid or int(fields[3]) != pgid:
                continue
            status = (directory / 'status').read_text()
            memory = {name: int(value) for name, value in re.findall(r'^(VmRSS|VmHWM):\s*(\d+) kB$', status, re.M)}
            members.append({'pid': int(directory.name), 'ppid': int(fields[1]),
                'process_group': int(fields[2]), 'session': int(fields[3]), 'state': fields[0],
                'comm': raw[raw.index('(') + 1:close], 'start_ticks': int(fields[19]),
                'user_ticks': int(fields[11]), 'system_ticks': int(fields[12]),
                'user_seconds': int(fields[11]) / ticks, 'system_seconds': int(fields[12]) / ticks,
                'threads': int(fields[17]), 'memory_kib': memory,
                'cmdline': (directory / 'cmdline').read_bytes().replace(b'\0', b' ').decode(errors='replace')})
        except (FileNotFoundError, ProcessLookupError, PermissionError, ValueError, IndexError):
            continue
    return sorted(members, key=lambda row: row['pid'])


def parse_progress(path):
    rows = []
    if path.is_file():
        for line in path.read_text().splitlines():
            if line.startswith('OBS superscalar_progress '):
                rows.append({key: int(value) if re.fullmatch(r'-?\d+', value) else value
                             for key, value in re.findall(r'(\w+)=([^ ]+)', line)})
    return rows


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--expected-head', required=True)
    parser.add_argument('--hosted-archive', type=Path, required=True)
    parser.add_argument('--hosted-archive-sha256', required=True)
    parser.add_argument('--local-out', type=Path, required=True)
    parser.add_argument('--local-receipt', type=Path, required=True)
    parser.add_argument('--local-receipt-sha256', required=True)
    parser.add_argument('--local-verify', type=Path, required=True)
    args = parser.parse_args()
    out = args.out.resolve()
    if out.exists() or ROOT == out or ROOT in out.parents or not re.fullmatch(r'[-A-Za-z0-9_./]+', str(out)):
        parser.error('fresh unambiguous output directory outside source required')
    for preserved in [args.local_out.resolve(), args.local_receipt.resolve().parent, args.hosted_archive.resolve().parent]:
        if out == preserved or preserved in out.parents:
            parser.error('output must not be placed in a preserved execution/artifact directory')
    for value in [args.expected_head, args.hosted_archive_sha256, args.local_receipt_sha256]:
        if not re.fullmatch(r'[0-9a-f]{40}|[0-9a-f]{64}', value):
            parser.error('full source/receipt/archive digest required')
    out.mkdir(parents=True)
    summary = {'schema': 'openrx.superscalar-bounded-progress-probe.v1',
        'status': 'diagnostic_running', 'scientific_acceptance': 'unverified', 'acceptance': False,
        'complete_validation': False, 'mode': 'reset', 'arms': {}, 'global_clock_cap_per_arm': CAP,
        'wall_limit_seconds_per_process': WALL_SECONDS, 'matrix_is_sequential': True,
        'boundary': 'Partial observer-only prefixes. No native generation, synthesis, full-mode rerun or scientific acceptance.'}
    original_bindings = []
    commands = []
    libc = ctypes.CDLL(None, use_errno=True)

    def retained(path):
        row = binding(path)
        original_bindings.append(row)
        return row

    def run(label, argv, progress=None):
        """Cap fixed tools in their original group/session; never signal after reap.

        This does not promise containment of a descendant that changes its
        process group/session. The admitted runner cgroup is the outer boundary.
        """
        log_path = out / (label + '.log')
        sample_path = out / (label + '-process-samples.jsonl')
        row = {'label': label, 'argv': [str(x) for x in argv], 'cwd': str(ROOT),
               'wall_limit_seconds': WALL_SECONDS, 'started_utc': datetime.now(timezone.utc).isoformat()}
        commands.append(row)
        save(out / 'commands.json', commands)
        began = time.monotonic()
        timed_out = False
        samples = []
        with log_path.open('w') as log, sample_path.open('w') as observations:
            child = subprocess.Popen(row['argv'], cwd=ROOT, stdout=log, stderr=subprocess.STDOUT,
                                     start_new_session=True)
            try:
                pgid = child.pid
                row['process_group'] = pgid
                row['cleanup_scope'] = 'Known fixed tools retaining the original PGID/SID; no escaped-group/session guarantee. Runner cgroup remains outer containment.'
                save(out / 'commands.json', commands)
                while True:
                    elapsed = time.monotonic() - began
                    members = process_group(pgid)
                    steps = parse_progress(progress) if progress else []
                    sample = {'elapsed_seconds': elapsed, 'members': members,
                              'last_progress': steps[-1] if steps else None}
                    samples.append(sample)
                    observations.write(json.dumps(sample, sort_keys=True) + '\n')
                    observations.flush()
                    # Peek only: the unreaped leader pins the numeric PGID until
                    # every possible group signal below has finished.
                    exited = os.waitid(os.P_PID, child.pid, os.WEXITED | os.WNOHANG | os.WNOWAIT)
                    if exited is not None:
                        row['leader_exit_observed_without_reap'] = {'pid': exited.si_pid,
                            'code': exited.si_code, 'status': exited.si_status}
                        break
                    remaining = WALL_SECONDS - (time.monotonic() - began)
                    if remaining <= 0:
                        timed_out = True
                        row['timeout_final_group_sample'] = members
                        break
                    time.sleep(min(1, remaining))
            finally:
                # This guard begins immediately after spawn, before any logging.
                # WNOWAIT verifies a still-waitable child without releasing its
                # PID. No poll()/wait() may reap it before the final group signal.
                pgid = child.pid
                os.waitid(os.P_PID, child.pid, os.WEXITED | os.WNOHANG | os.WNOWAIT)
                if os.getpgid(child.pid) != pgid or os.getsid(child.pid) != pgid:
                    raise RuntimeError('fixed-tool leader left its original PGID/SID; no group signal sent')
                try:
                    os.killpg(pgid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
                # All group signals are now complete. Reaping may release the
                # leader identity; no subsequent cleanup operation signals PGID.
                row['returncode'] = child.wait(timeout=2)
                reaped = []
                cleanup_deadline = time.monotonic() + 2
                while True:
                    try:
                        pid, status = os.waitpid(-pgid, os.WNOHANG)
                        if pid:
                            reaped.append({'pid': pid, 'wait_status': status})
                            continue
                    except ChildProcessError:
                        pass
                    surviving = process_group(pgid)
                    if not surviving:
                        break
                    if time.monotonic() >= cleanup_deadline:
                        raise RuntimeError('process group remains after bounded kill/reap: ' + repr(surviving))
                    time.sleep(0.02)
                row['reaped_adopted_descendants'] = reaped
                row['group_empty_after_cleanup'] = True
                save(out / 'commands.json', commands)
        row['wall_timeout'] = timed_out
        row['elapsed_seconds_including_cleanup'] = time.monotonic() - began
        observed = [member for sample in samples for member in sample['members']]
        row['maximum_sampled_rss_kib'] = max((m['memory_kib'].get('VmRSS', 0) for m in observed), default=0)
        row['maximum_observed_hwm_kib'] = max((m['memory_kib'].get('VmHWM', 0) for m in observed), default=0)
        row['largest_sampled_cpu_seconds'] = max((m['user_seconds'] + m['system_seconds'] for m in observed), default=0)
        row['resource_boundary'] = 'Periodic actual /proc observations; not an unsampled true process/resource peak.'
        save(out / 'commands.json', commands)
        return row

    try:
        assert source_head() == args.expected_head
        assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT, text=True).strip()
        assert sha(BENCH) == BENCH_SHA and sha(OBSERVER) == OBSERVER_SHA
        summary['new_source'] = {'head': args.expected_head, 'bench': retained(BENCH),
            'observer': retained(OBSERVER), 'driver': retained(Path(__file__).resolve())}
        # Linux subreaper is local to this diagnostic process, not host settings.
        # It lets the same process reap compiler grandchildren after group kill.
        if libc.prctl(36, 1, 0, 0, 0) != 0:
            raise OSError(ctypes.get_errno(), 'PR_SET_CHILD_SUBREAPER unavailable')
        summary['process_local_subreaper_enabled'] = True
        summary['host_observation'] = {'cpu_count': os.cpu_count(), 'affinity': sorted(os.sched_getaffinity(0)),
            'clock_ticks_per_second': os.sysconf('SC_CLK_TCK'), 'loadavg': list(os.getloadavg()),
            'cpu_models': sorted(set(re.findall(r'^model name\s*:\s*(.+)$', Path('/proc/cpuinfo').read_text(), re.M))),
            'self_cgroup': Path('/proc/self/cgroup').read_text()}
        receipt_path, verify_path = args.local_receipt.resolve(), args.local_verify.resolve()
        assert sha(receipt_path) == args.local_receipt_sha256
        receipt, verify = load(receipt_path), load(verify_path)
        assert receipt['status'] == verify['status'] == 'PROCESS_EXITED' and receipt['process']['returncode'] == 0
        assert verify['integrity_verified'] is True and verify['execution_id'] == receipt['execution_id']
        retained(receipt_path); retained(verify_path)
        artifacts = {Path(row['path']): row for row in receipt['artifacts']}

        def receipt_bound(path):
            value = retained(path)
            expected = artifacts[path]
            assert value['sha256'] == expected['sha256'] and value['bytes'] == expected['bytes']
            return value

        local = args.local_out.resolve()
        for name in [NETLIST, CELLS, 'summary.json', 'inputs.json', 'tools.json', 'fixtures.sha256.json']:
            receipt_bound(local / name)
        assert load(local / 'summary.json')['status'] == 'pass'
        inputs = load(local / 'inputs.json')
        for relative, expected in inputs.items():
            assert sha(ROOT / relative) == expected, 'frozen validation input changed: ' + relative
        summary['unchanged_validation_source_files'] = len(inputs)
        fixtures = local / 'fixtures'
        fixture_hashes = load(local / 'fixtures.sha256.json')
        assert len(fixture_hashes) == 1178
        assert {str(p.relative_to(fixtures)) for p in fixtures.rglob('*') if p.is_file()} == set(fixture_hashes)
        for relative, expected in fixture_hashes.items():
            row = receipt_bound(fixtures / relative)
            assert row['sha256'] == expected
        archive = args.hosted_archive.resolve()
        assert sha(archive) == args.hosted_archive_sha256
        summary['hosted_archive'] = retained(archive)
        copied = out / 'compiled-inputs'
        copied.mkdir()
        with zipfile.ZipFile(archive) as bundle:
            names = bundle.namelist()
            assert len(names) == len(set(names)) == 1259
            inventory = json.loads(bundle.read('artifacts.sha256.json'))
            assert set(inventory) == set(names) - {'artifacts.sha256.json'}
            for name, expected in inventory.items():
                assert hashlib.sha256(bundle.read(name)).hexdigest() == expected
            assert json.loads(bundle.read('fixtures.sha256.json')) == fixture_hashes
            assert {n[len('fixtures/'):] for n in names if n.startswith('fixtures/')} == set(fixture_hashes)
            for relative, expected in fixture_hashes.items():
                assert inventory['fixtures/' + relative] == expected
                assert bundle.getinfo('fixtures/' + relative).file_size == (fixtures / relative).stat().st_size
                assert hashlib.sha256(bundle.read('fixtures/' + relative)).hexdigest() == expected
            for name in [NETLIST, CELLS]:
                (copied / ('hosted-' + name)).write_bytes(bundle.read(name))
                assert sha(copied / ('hosted-' + name)) == inventory[name]
        for name in [NETLIST, CELLS]:
            shutil.copyfile(local / name, copied / ('local-' + name))
            assert sha(copied / ('local-' + name)) == sha(local / name)
        summary['fixture_identity'] = {'files': len(fixture_hashes), 'bytes': sum((fixtures / x).stat().st_size for x in fixture_hashes),
            'hosted_local_exact_sha_size_names_match': True, 'normalization': False,
            'fixture_root': str(fixtures), 'fixture_inventory_sha256': sha(local / 'fixtures.sha256.json')}
        tools = {}
        local_tools = load(local / 'tools.json')
        for name in ['iverilog', 'vvp']:
            located = shutil.which(name)
            assert located, 'missing tool: ' + name
            tools[name] = Path(located).resolve()
            row = retained(tools[name])
            assert row['sha256'] == local_tools[name]['sha256'], 'different local diagnostic tool: ' + name
        save(out / 'input-bindings.json', original_bindings)
        for origin in ['local', 'hosted']:
            executable = out / (origin + '.vvp')
            compile_row = run('compile-' + origin, [tools['iverilog'], '-g2012', '-Wall',
                '-s', 'tb_superscalar_execute', '-s', 'superscalar_progress_observer',
                '-Ptb_superscalar_execute.MUL_RADIX4=1', '-DSUPERSCALAR_NETLIST', '-o', executable,
                copied / (origin + '-' + NETLIST), copied / (origin + '-' + CELLS), BENCH, OBSERVER])
            assert compile_row['returncode'] == 0 and not compile_row['wall_timeout'], 'diagnostic compile failed'
            progress = out / (origin + '-reset-progress.log')
            row = run(origin + '-reset', [tools['vvp'], '-v', executable, '+DIR=' + str(fixtures),
                '+CASES=cases-control.hex', '+MODE=reset', '+RESULTS=' + str(out / (origin + '-reset-latencies.hex')),
                '+PROGRESS=' + str(progress), '+DIAGNOSTIC_CYCLES=' + str(CAP)], progress)
            log = (out / (origin + '-reset.log')).read_text()
            assert not any(line.startswith('PASS ') for line in log.splitlines()), 'unexpected complete validation marker'
            assert 'FATAL:' not in log and 'FAIL ' not in log, 'original assertion failed in diagnostic prefix'
            checkpoints = parse_progress(progress)
            if checkpoints:
                assert checkpoints[0]['settled_ticks'] > 0
            if row['wall_timeout']:
                outcome = 'DIAGNOSTIC_PARTIAL_WALL_LIMIT'
            else:
                assert row['returncode'] == 0
                assert 'DIAGNOSTIC_PARTIAL superscalar_execute mode=reset settled_ticks=8192 cap=8192' in log
                assert checkpoints, 'clock-limit marker without progress records'
                assert checkpoints[-1]['settled_ticks'] == CAP
                outcome = 'DIAGNOSTIC_PARTIAL_CLOCK_LIMIT'
            summary['arms'][origin] = {'outcome': outcome, 'acceptance': False, 'command': row,
                'compiled_netlist': binding(copied / (origin + '-' + NETLIST)),
                'cell_model': binding(copied / (origin + '-' + CELLS)), 'compiled_vvp': binding(executable),
                'last_progress': checkpoints[-1] if checkpoints else None, 'progress_records': len(checkpoints)}
            save(out / 'summary.json', summary)
        local_rows = {row['settled_ticks']: row for row in parse_progress(out / 'local-reset-progress.log')}
        hosted_rows = {row['settled_ticks']: row for row in parse_progress(out / 'hosted-reset-progress.log')}
        common = sorted(set(local_rows) & set(hosted_rows))
        summary['common_observation_checkpoints'] = {'ticks': common,
            'equal': all(local_rows[tick] == hosted_rows[tick] for tick in common) if common else None,
            'boundary': 'Observed shared prefix only, not complete validation or scientific acceptance.'}
        assert all(binding(Path(row['path'])) == row for row in original_bindings), 'retained input changed'
        assert all(sha(ROOT / relative) == expected for relative, expected in inputs.items())
        assert source_head() == args.expected_head
        assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT, text=True).strip()
        summary['retained_inputs_and_source_unchanged'] = True
        summary['status'] = 'DIAGNOSTIC_PARTIAL_OBSERVATION_ONLY'
        print('DIAGNOSTIC_PARTIAL superscalar_probe arms=2 mode=reset acceptance=0', flush=True)
    except Exception as error:
        summary['status'] = 'DIAGNOSTIC_ERROR_NO_ACCEPTANCE'
        summary['error'] = str(error)
        raise
    finally:
        save(out / 'summary.json', summary)
        save(out / 'artifacts.sha256.json', {str(p.relative_to(out)): sha(p)
            for p in sorted(out.rglob('*')) if p.is_file() and p != out / 'artifacts.sha256.json'})


if __name__ == '__main__':
    main()
