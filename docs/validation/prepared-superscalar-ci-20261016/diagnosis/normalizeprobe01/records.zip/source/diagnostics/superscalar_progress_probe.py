#!/usr/bin/env python3
"""Bounded data-bound RESET-prefix observation; never a validation PASS.

Authoring does not execute this driver. Run only in a separately reviewed and
admitted payload. The original mode observes two retained local/hosted netlists.
The opt-in normalization mode observes only one transformed hosted netlist and
compares it with receipt-bound prior observations without repeating them. This
ordinary proc/techmap experiment covers the current binary-control prepared
program domain; it makes no arbitrary X/Z equivalence claim. The four-state
Icarus bench and all original assertions remain unchanged. No native generation,
full synthesis, full-mode repeat or scientific acceptance is performed.
"""
import argparse
from collections import Counter
import ctypes
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import signal
import subprocess
import time
import zipfile

ROOT = Path(__file__).resolve().parents[1]
BENCH = ROOT / 'rtl/execute/tests/tb_superscalar_execute.v'
OBSERVER = ROOT / 'diagnostics/superscalar_progress_observer.v'
BENCH_SHA = '33d7cc3396edf08f3a3e0827a5178ee18a366d19e9438e024e9dc60ea224fd24'
OBSERVER_SHA = '75c647fa86b3f559bd93bb392d3ad8eac1ae0648eda2e683a49ae6f51b0687fb'
CAP = 8192
WALL_SECONDS = 60
NETLIST = 'netlist-superscalar.v'
CELLS = 'yosys-simcells.v'
NETLIST_JSON = 'netlist-superscalar.json'
TOP = 'randomx_superscalar_execute'
COMBINATIONAL_TYPES = {'$_NOT_', '$_AND_', '$_OR_', '$_XOR_', '$_XNOR_',
    '$_NAND_', '$_NOR_', '$_ANDNOT_', '$_ORNOT_', '$_MUX_',
    '$_AOI3_', '$_AOI4_', '$_OAI3_', '$_OAI4_'}


def sha(path):
    value = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            value.update(block)
    return value.hexdigest()


def load(path):
    return json.loads(path.read_text())


def save(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


def binding(path):
    assert path.is_file() and not path.is_symlink(), str(path)
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': sha(path)}


def source_head():
    return subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()


def process_group(pgid):
    """Snapshot only this newly created session/group; tolerate exit races."""
    members = []
    ticks = os.sysconf('SC_CLK_TCK')
    for directory in Path('/proc').iterdir():
        if not directory.name.isdigit():
            continue
        try:
            raw = (directory / 'stat').read_text()
            close = raw.rindex(')')
            fields = raw[close + 2:].split()
            if int(fields[2]) != pgid or int(fields[3]) != pgid:
                continue
            status = (directory / 'status').read_text()
            memory = {name: int(value) for name, value in re.findall(r'^(VmRSS|VmHWM):\s*(\d+) kB$', status, re.M)}
            members.append({'pid': int(directory.name), 'ppid': int(fields[1]),
                'process_group': int(fields[2]), 'session': int(fields[3]), 'state': fields[0],
                'comm': raw[raw.index('(') + 1:close], 'start_ticks': int(fields[19]),
                'user_ticks': int(fields[11]), 'system_ticks': int(fields[12]),
                'user_seconds': int(fields[11]) / ticks, 'system_seconds': int(fields[12]) / ticks,
                'threads': int(fields[17]), 'memory_kib': memory,
                'cmdline': (directory / 'cmdline').read_bytes().replace(b'\0', b' ').decode(errors='replace')})
        except (FileNotFoundError, ProcessLookupError, PermissionError, ValueError, IndexError):
            continue
    return sorted(members, key=lambda row: row['pid'])


def parse_progress(path):
    rows = []
    if path.is_file():
        for line in path.read_text().splitlines():
            if line.startswith('OBS superscalar_progress '):
                rows.append({key: int(value) if re.fullmatch(r'-?\d+', value) else value
                             for key, value in re.findall(r'(\w+)=([^ ]+)', line)})
    return rows


def port_signature(module):
    """Port bit numbers are local to each JSON; preserve all other metadata."""
    return {name: dict({key: value for key, value in port.items() if key != 'bits'},
                       width=len(port['bits'])) for name, port in module['ports'].items()}


def checked_normalized_netlist(path, original):
    design = load(path)
    assert set(design['modules']) == {TOP}, 'unexpected normalized modules'
    module = design['modules'][TOP]
    assert not module.get('processes') and not module.get('memories'), 'remaining process/memory'
    assert len(original['ports']) == len(module['ports']) == 45
    assert port_signature(module) == port_signature(original), 'normalized top ports changed'
    types = Counter(cell['type'] for cell in module['cells'].values())
    assert types['$_DFF_P_'] == 1387, 'expected exactly 1387 positive-edge plain DFF cells'
    assert set(types) <= COMBINATIONAL_TYPES | {'$_DFF_P_'}, 'unknown/sequential normalized cell type'
    for cell in module['cells'].values():
        if cell['type'] == '$_DFF_P_':
            assert cell['connections']['C'] == module['ports']['clk']['bits'], 'unexpected FF clock'
            assert len(cell['connections']['D']) == len(cell['connections']['Q']) == 1
    return {'netlist_json': binding(path), 'top_ports': port_signature(module),
        'ports_match_original': True, 'ports': 45, 'cells': sum(types.values()),
        'cell_types': dict(sorted(types.items())), 'plain_positive_dffs': 1387,
        'latches': 0, 'other_sequential_cells': 0,
        'boundary': 'Actual post-transform cell types/counts, separate from either original mapping. Binary-control scope only; no arbitrary X/Z equivalence or physical PPA claim.'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--expected-head', required=True)
    parser.add_argument('--hosted-archive', type=Path, required=True)
    parser.add_argument('--hosted-archive-sha256', required=True)
    parser.add_argument('--local-out', type=Path, required=True)
    parser.add_argument('--local-receipt', type=Path, required=True)
    parser.add_argument('--local-receipt-sha256', required=True)
    parser.add_argument('--local-verify', type=Path, required=True)
    parser.add_argument('--normalize-hosted', action='store_true')
    parser.add_argument('--baseline-receipt', type=Path)
    parser.add_argument('--baseline-receipt-sha256')
    parser.add_argument('--baseline-verify', type=Path)
    parser.add_argument('--baseline-verify-sha256')
    parser.add_argument('--yosys-share', type=Path)
    args = parser.parse_args()
    baseline_args = [args.baseline_receipt, args.baseline_receipt_sha256,
                     args.baseline_verify, args.baseline_verify_sha256, args.yosys_share]
    if args.normalize_hosted != all(value is not None for value in baseline_args):
        parser.error('--normalize-hosted requires all four baseline binding arguments and --yosys-share')
    if not args.normalize_hosted and any(value is not None for value in baseline_args):
        parser.error('baseline/Yosys-share arguments apply only to --normalize-hosted')
    out = args.out.resolve()
    if out.exists() or ROOT == out or ROOT in out.parents or not re.fullmatch(r'[-A-Za-z0-9_./]+', str(out)):
        parser.error('fresh unambiguous output directory outside source required')
    preserved_roots = [args.local_out.resolve(), args.local_receipt.resolve().parent, args.hosted_archive.resolve().parent]
    if args.normalize_hosted:
        preserved_roots.append(args.baseline_receipt.resolve().parent)
    for preserved in preserved_roots:
        if out == preserved or preserved in out.parents:
            parser.error('output must not be placed in a preserved execution/artifact directory')
    for value in [args.expected_head, args.hosted_archive_sha256, args.local_receipt_sha256]:
        if not re.fullmatch(r'[0-9a-f]{40}|[0-9a-f]{64}', value):
            parser.error('full source/receipt/archive digest required')
    if args.normalize_hosted:
        for value in [args.baseline_receipt_sha256, args.baseline_verify_sha256]:
            if not re.fullmatch(r'[0-9a-f]{64}', value):
                parser.error('full baseline receipt/verification SHA256 required')
        if not re.fullmatch(r'[-A-Za-z0-9_./]+', str(args.yosys_share.resolve())):
            parser.error('unambiguous Yosys share path required')
    out.mkdir(parents=True)
    summary = {'schema': 'openrx.superscalar-bounded-progress-probe.v1',
        'status': 'diagnostic_running', 'scientific_acceptance': 'unverified', 'acceptance': False,
        'complete_validation': False, 'mode': 'reset', 'arms': {}, 'global_clock_cap_per_arm': CAP,
        'wall_limit_seconds_per_process': WALL_SECONDS, 'matrix_is_sequential': True,
        'boundary': 'Partial observer-only prefixes. No native generation, synthesis, full-mode rerun or scientific acceptance.'}
    if args.normalize_hosted:
        summary['variant'] = 'one-normalized-hosted-arm-with-retained-baselines'
        summary['maximum_processes'] = 3
        summary['maximum_command_wall_seconds_sum'] = 180
        summary['boundary'] = 'One ordinary proc/techmap RESET-prefix experiment in the current binary-control prepared-program domain, using four-state Icarus and unchanged assertions. No arbitrary X/Z equivalence, native generation, full synthesis, full-mode repeat or scientific acceptance.'
    original_bindings = []
    commands = []
    libc = ctypes.CDLL(None, use_errno=True)

    def retained(path):
        row = binding(path)
        original_bindings.append(row)
        return row

    def run(label, argv, progress=None):
        """Cap fixed tools in their original group/session; never signal after reap.

        This does not promise containment of a descendant that changes its
        process group/session. The admitted runner cgroup is the outer boundary.
        """
        log_path = out / (label + '.log')
        sample_path = out / (label + '-process-samples.jsonl')
        row = {'label': label, 'argv': [str(x) for x in argv], 'cwd': str(ROOT),
               'wall_limit_seconds': WALL_SECONDS, 'started_utc': datetime.now(timezone.utc).isoformat()}
        commands.append(row)
        save(out / 'commands.json', commands)
        began = time.monotonic()
        timed_out = False
        samples = []
        with log_path.open('w') as log, sample_path.open('w') as observations:
            child = subprocess.Popen(row['argv'], cwd=ROOT, stdout=log, stderr=subprocess.STDOUT,
                                     start_new_session=True)
            try:
                pgid = child.pid
                row['process_group'] = pgid
                row['cleanup_scope'] = 'Known fixed tools retaining the original PGID/SID; no escaped-group/session guarantee. Runner cgroup remains outer containment.'
                save(out / 'commands.json', commands)
                while True:
                    elapsed = time.monotonic() - began
                    members = process_group(pgid)
                    steps = parse_progress(progress) if progress else []
                    sample = {'elapsed_seconds': elapsed, 'members': members,
                              'last_progress': steps[-1] if steps else None}
                    samples.append(sample)
                    observations.write(json.dumps(sample, sort_keys=True) + '\n')
                    observations.flush()
                    # Peek only: the unreaped leader pins the numeric PGID until
                    # every possible group signal below has finished.
                    exited = os.waitid(os.P_PID, child.pid, os.WEXITED | os.WNOHANG | os.WNOWAIT)
                    if exited is not None:
                        row['leader_exit_observed_without_reap'] = {'pid': exited.si_pid,
                            'code': exited.si_code, 'status': exited.si_status}
                        break
                    remaining = WALL_SECONDS - (time.monotonic() - began)
                    if remaining <= 0:
                        timed_out = True
                        row['timeout_final_group_sample'] = members
                        break
                    time.sleep(min(1, remaining))
            finally:
                # This guard begins immediately after spawn, before any logging.
                # WNOWAIT verifies a still-waitable child without releasing its
                # PID. No poll()/wait() may reap it before the final group signal.
                pgid = child.pid
                os.waitid(os.P_PID, child.pid, os.WEXITED | os.WNOHANG | os.WNOWAIT)
                if os.getpgid(child.pid) != pgid or os.getsid(child.pid) != pgid:
                    raise RuntimeError('fixed-tool leader left its original PGID/SID; no group signal sent')
                try:
                    os.killpg(pgid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
                # All group signals are now complete. Reaping may release the
                # leader identity; no subsequent cleanup operation signals PGID.
                row['returncode'] = child.wait(timeout=2)
                reaped = []
                cleanup_deadline = time.monotonic() + 2
                while True:
                    try:
                        pid, status = os.waitpid(-pgid, os.WNOHANG)
                        if pid:
                            reaped.append({'pid': pid, 'wait_status': status})
                            continue
                    except ChildProcessError:
                        pass
                    surviving = process_group(pgid)
                    if not surviving:
                        break
                    if time.monotonic() >= cleanup_deadline:
                        raise RuntimeError('process group remains after bounded kill/reap: ' + repr(surviving))
                    time.sleep(0.02)
                row['reaped_adopted_descendants'] = reaped
                row['group_empty_after_cleanup'] = True
                save(out / 'commands.json', commands)
        row['wall_timeout'] = timed_out
        row['elapsed_seconds_including_cleanup'] = time.monotonic() - began
        observed = [member for sample in samples for member in sample['members']]
        row['maximum_sampled_rss_kib'] = max((m['memory_kib'].get('VmRSS', 0) for m in observed), default=0)
        row['maximum_observed_hwm_kib'] = max((m['memory_kib'].get('VmHWM', 0) for m in observed), default=0)
        row['largest_sampled_cpu_seconds'] = max((m['user_seconds'] + m['system_seconds'] for m in observed), default=0)
        row['resource_boundary'] = 'Periodic actual /proc observations; not an unsampled true process/resource peak.'
        save(out / 'commands.json', commands)
        return row

    try:
        assert source_head() == args.expected_head
        assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT, text=True).strip()
        assert sha(BENCH) == BENCH_SHA and sha(OBSERVER) == OBSERVER_SHA
        summary['new_source'] = {'head': args.expected_head, 'bench': retained(BENCH),
            'observer': retained(OBSERVER), 'driver': retained(Path(__file__).resolve())}
        # Linux subreaper is local to this diagnostic process, not host settings.
        # It lets the same process reap compiler grandchildren after group kill.
        if libc.prctl(36, 1, 0, 0, 0) != 0:
            raise OSError(ctypes.get_errno(), 'PR_SET_CHILD_SUBREAPER unavailable')
        summary['process_local_subreaper_enabled'] = True
        summary['host_observation'] = {'cpu_count': os.cpu_count(), 'affinity': sorted(os.sched_getaffinity(0)),
            'clock_ticks_per_second': os.sysconf('SC_CLK_TCK'), 'loadavg': list(os.getloadavg()),
            'cpu_models': sorted(set(re.findall(r'^model name\s*:\s*(.+)$', Path('/proc/cpuinfo').read_text(), re.M))),
            'self_cgroup': Path('/proc/self/cgroup').read_text()}
        receipt_path, verify_path = args.local_receipt.resolve(), args.local_verify.resolve()
        assert sha(receipt_path) == args.local_receipt_sha256
        receipt, verify = load(receipt_path), load(verify_path)
        assert receipt['status'] == verify['status'] == 'PROCESS_EXITED' and receipt['process']['returncode'] == 0
        assert verify['integrity_verified'] is True and verify['execution_id'] == receipt['execution_id']
        retained(receipt_path); retained(verify_path)
        artifacts = {Path(row['path']): row for row in receipt['artifacts']}

        def receipt_bound(path):
            value = retained(path)
            expected = artifacts[path]
            assert value['sha256'] == expected['sha256'] and value['bytes'] == expected['bytes']
            return value

        local = args.local_out.resolve()
        for name in [NETLIST, CELLS, 'summary.json', 'inputs.json', 'tools.json', 'fixtures.sha256.json']:
            receipt_bound(local / name)
        assert load(local / 'summary.json')['status'] == 'pass'
        inputs = load(local / 'inputs.json')
        for relative, expected in inputs.items():
            assert sha(ROOT / relative) == expected, 'frozen validation input changed: ' + relative
        summary['unchanged_validation_source_files'] = len(inputs)
        fixtures = local / 'fixtures'
        fixture_hashes = load(local / 'fixtures.sha256.json')
        assert len(fixture_hashes) == 1178
        assert {str(p.relative_to(fixtures)) for p in fixtures.rglob('*') if p.is_file()} == set(fixture_hashes)
        for relative, expected in fixture_hashes.items():
            row = receipt_bound(fixtures / relative)
            assert row['sha256'] == expected
        archive = args.hosted_archive.resolve()
        assert sha(archive) == args.hosted_archive_sha256
        summary['hosted_archive'] = retained(archive)
        copied = out / 'compiled-inputs'
        copied.mkdir()
        with zipfile.ZipFile(archive) as bundle:
            names = bundle.namelist()
            assert len(names) == len(set(names)) == 1259
            inventory = json.loads(bundle.read('artifacts.sha256.json'))
            assert set(inventory) == set(names) - {'artifacts.sha256.json'}
            for name, expected in inventory.items():
                assert hashlib.sha256(bundle.read(name)).hexdigest() == expected
            assert json.loads(bundle.read('fixtures.sha256.json')) == fixture_hashes
            assert {n[len('fixtures/'):] for n in names if n.startswith('fixtures/')} == set(fixture_hashes)
            for relative, expected in fixture_hashes.items():
                assert inventory['fixtures/' + relative] == expected
                assert bundle.getinfo('fixtures/' + relative).file_size == (fixtures / relative).stat().st_size
                assert hashlib.sha256(bundle.read('fixtures/' + relative)).hexdigest() == expected
            for name in [NETLIST, CELLS] + ([NETLIST_JSON] if args.normalize_hosted else []):
                (copied / ('hosted-' + name)).write_bytes(bundle.read(name))
                assert sha(copied / ('hosted-' + name)) == inventory[name]
        for name in [NETLIST, CELLS]:
            shutil.copyfile(local / name, copied / ('local-' + name))
            assert sha(copied / ('local-' + name)) == sha(local / name)
        summary['fixture_identity'] = {'files': len(fixture_hashes), 'bytes': sum((fixtures / x).stat().st_size for x in fixture_hashes),
            'hosted_local_exact_sha_size_names_match': True, 'normalization': False,
            'fixture_root': str(fixtures), 'fixture_inventory_sha256': sha(local / 'fixtures.sha256.json')}
        tools = {}
        local_tools = load(local / 'tools.json')
        for name in ['iverilog', 'vvp'] + (['yosys'] if args.normalize_hosted else []):
            located = shutil.which(name)
            assert located, 'missing tool: ' + name
            tools[name] = Path(located).resolve()
            row = retained(tools[name])
            assert row['sha256'] == local_tools[name]['sha256'], 'different local diagnostic tool: ' + name
        baseline_rows = {}
        if args.normalize_hosted:
            baseline_receipt_path = args.baseline_receipt.resolve()
            baseline_verify_path = args.baseline_verify.resolve()
            assert sha(baseline_receipt_path) == args.baseline_receipt_sha256
            assert sha(baseline_verify_path) == args.baseline_verify_sha256
            baseline_receipt = load(baseline_receipt_path)
            baseline_verify = load(baseline_verify_path)
            assert baseline_receipt['status'] == baseline_verify['status'] == 'PROCESS_EXITED'
            assert baseline_receipt['process']['returncode'] == 0
            assert baseline_verify['integrity_verified'] is True
            assert baseline_receipt['execution_id'] == baseline_verify['execution_id']
            baseline_out = baseline_receipt_path.parent / 'output'
            baseline_artifacts = {Path(row['path']): row for row in baseline_receipt['artifacts']}

            def baseline_bound(path):
                assert baseline_out in path.parents, 'baseline artifact outside retained output'
                row = retained(path)
                expected = baseline_artifacts[path]
                assert row['sha256'] == expected['sha256'] and row['bytes'] == expected['bytes']
                return row

            baseline_summary_binding = baseline_bound(baseline_out / 'summary.json')
            baseline_summary = load(baseline_out / 'summary.json')
            assert baseline_summary['schema'] == 'openrx.superscalar-bounded-progress-probe.v1'
            assert baseline_summary['status'] == 'DIAGNOSTIC_PARTIAL_OBSERVATION_ONLY'
            assert baseline_summary['acceptance'] is False and baseline_summary['complete_validation'] is False
            assert baseline_summary['scientific_acceptance'] == 'unverified'
            assert baseline_summary['mode'] == 'reset' and baseline_summary['global_clock_cap_per_arm'] == CAP
            assert set(baseline_summary['arms']) == {'local', 'hosted'}
            assert baseline_summary['new_source']['bench']['sha256'] == BENCH_SHA
            assert baseline_summary['new_source']['observer']['sha256'] == OBSERVER_SHA
            assert baseline_summary['unchanged_validation_source_files'] == len(inputs) == 178
            assert baseline_summary['fixture_identity']['fixture_inventory_sha256'] == sha(local / 'fixtures.sha256.json')
            assert baseline_summary['fixture_identity']['files'] == len(fixture_hashes)
            assert baseline_summary['hosted_archive']['sha256'] == args.hosted_archive_sha256
            baseline_bound(baseline_out / 'input-bindings.json')
            old_inputs = {row['path']: row for row in load(baseline_out / 'input-bindings.json')}
            for path in [receipt_path, local / 'inputs.json', local / 'tools.json', local / 'fixtures.sha256.json']:
                assert old_inputs[str(path)] == binding(path), 'baseline trusted input identity differs'
            progress_bindings = {}
            for origin in ['local', 'hosted']:
                old_arm = baseline_summary['arms'][origin]
                assert old_arm['acceptance'] is False and old_arm['command']['group_empty_after_cleanup'] is True
                for key, raw_name in [('compiled_netlist', NETLIST), ('cell_model', CELLS)]:
                    old = baseline_bound(Path(old_arm[key]['path']))
                    assert old == old_arm[key]
                    assert old['sha256'] == sha(copied / (origin + '-' + raw_name))
                progress_path = baseline_out / (origin + '-reset-progress.log')
                progress_bindings[origin] = baseline_bound(progress_path)
                rows = parse_progress(progress_path)
                assert rows and rows[-1] == old_arm['last_progress']
                assert len(rows) == old_arm['progress_records']
                baseline_rows[origin] = {row['settled_ticks']: row for row in rows}
                assert len(baseline_rows[origin]) == len(rows), 'duplicate baseline checkpoint'
            common = sorted(set(baseline_rows['local']) & set(baseline_rows['hosted']))
            assert common and all(baseline_rows['local'][tick] == baseline_rows['hosted'][tick] for tick in common)
            assert baseline_summary['common_observation_checkpoints']['equal'] is True
            assert baseline_summary['common_observation_checkpoints']['ticks'] == common
            summary['retained_baselines'] = {'receipt': retained(baseline_receipt_path),
                'root_verification': retained(baseline_verify_path), 'summary': baseline_summary_binding,
                'progress': progress_bindings, 'shared_ticks': common, 'shared_rows_equal': True,
                'boundary': 'Prior actual receipt-hashed observations are compared as data; neither baseline process is repeated and no scientific acceptance is imported.'}
            share = args.yosys_share.resolve()
            assert share.is_dir() and (share / 'techmap.v').is_file()
            share_paths = sorted(path for path in share.rglob('*') if path.is_file())
            assert share_paths and not any(path.is_symlink() for path in share.rglob('*'))
            share_bindings = [retained(path) for path in share_paths]
            summary['normalization_tool'] = {'yosys': binding(tools['yosys']),
                'matches_original_local_tool_sha256': True, 'share_root': str(share),
                'share_files': share_bindings,
                'boundary': 'Actual bound installed Yosys/share files; no tool installation or full synthesis.'}
        save(out / 'input-bindings.json', original_bindings)
        origins = ['local', 'hosted']
        if args.normalize_hosted:
            normalized = copied / ('normalized-hosted-' + NETLIST)
            normalized_json = copied / ('normalized-hosted-' + NETLIST_JSON)
            script = out / 'normalize-hosted.ys'
            script.write_text('\n'.join([
                'read_verilog ' + str(copied / ('hosted-' + NETLIST)),
                'hierarchy -check -top ' + TOP,
                'proc', 'techmap -map ' + str(share / 'techmap.v'), 'opt_clean', 'check -assert', 'stat',
                'write_json ' + str(normalized_json), 'write_verilog -noattr ' + str(normalized), '']))
            transform = run('normalize-hosted', [tools['yosys'], '-Q', '-T', '-s', script])
            assert transform['returncode'] == 0 and not transform['wall_timeout'], 'normalization command failed'
            original_json = copied / ('hosted-' + NETLIST_JSON)
            original_design = load(original_json)
            assert set(original_design['modules']) == {TOP}
            original_module = original_design['modules'][TOP]
            original_types = Counter(cell['type'] for cell in original_module['cells'].values())
            post = checked_normalized_netlist(normalized_json, original_module)
            summary['normalization'] = {'command': transform, 'script': binding(script),
                'original_netlist': binding(copied / ('hosted-' + NETLIST)),
                'original_netlist_json': binding(original_json),
                'original_cells': sum(original_types.values()), 'original_cell_types': dict(sorted(original_types.items())),
                'post_transform': post, 'normalized_verilog': binding(normalized),
                'allowed_passes': ['read_verilog', 'hierarchy', 'proc', 'techmap', 'opt_clean', 'check', 'stat', 'write_json', 'write_verilog'],
                'binary_control_domain_only': True, 'arbitrary_x_z_equivalence_claimed': False,
                'original_mapping_and_cell_model_preserved': True}
            shutil.copyfile(copied / ('hosted-' + CELLS), copied / ('normalized-hosted-' + CELLS))
            assert sha(copied / ('normalized-hosted-' + CELLS)) == inventory[CELLS]
            origins = ['normalized-hosted']
            save(out / 'summary.json', summary)
        for origin in origins:
            executable = out / (origin + '.vvp')
            compile_row = run('compile-' + origin, [tools['iverilog'], '-g2012', '-Wall',
                '-s', 'tb_superscalar_execute', '-s', 'superscalar_progress_observer',
                '-Ptb_superscalar_execute.MUL_RADIX4=1', '-DSUPERSCALAR_NETLIST', '-o', executable,
                copied / (origin + '-' + NETLIST), copied / (origin + '-' + CELLS), BENCH, OBSERVER])
            assert compile_row['returncode'] == 0 and not compile_row['wall_timeout'], 'diagnostic compile failed'
            progress = out / (origin + '-reset-progress.log')
            row = run(origin + '-reset', [tools['vvp'], '-v', executable, '+DIR=' + str(fixtures),
                '+CASES=cases-control.hex', '+MODE=reset', '+RESULTS=' + str(out / (origin + '-reset-latencies.hex')),
                '+PROGRESS=' + str(progress), '+DIAGNOSTIC_CYCLES=' + str(CAP)], progress)
            log = (out / (origin + '-reset.log')).read_text()
            assert not any(line.startswith('PASS ') for line in log.splitlines()), 'unexpected complete validation marker'
            assert 'FATAL:' not in log and 'FAIL ' not in log, 'original assertion failed in diagnostic prefix'
            checkpoints = parse_progress(progress)
            if checkpoints:
                assert checkpoints[0]['settled_ticks'] > 0
            if row['wall_timeout']:
                outcome = 'DIAGNOSTIC_PARTIAL_WALL_LIMIT'
            else:
                assert row['returncode'] == 0
                assert 'DIAGNOSTIC_PARTIAL superscalar_execute mode=reset settled_ticks=8192 cap=8192' in log
                assert checkpoints, 'clock-limit marker without progress records'
                assert checkpoints[-1]['settled_ticks'] == CAP
                outcome = 'DIAGNOSTIC_PARTIAL_CLOCK_LIMIT'
            summary['arms'][origin] = {'outcome': outcome, 'acceptance': False, 'command': row,
                'compiled_netlist': binding(copied / (origin + '-' + NETLIST)),
                'cell_model': binding(copied / (origin + '-' + CELLS)), 'compiled_vvp': binding(executable),
                'last_progress': checkpoints[-1] if checkpoints else None, 'progress_records': len(checkpoints)}
            save(out / 'summary.json', summary)
        if args.normalize_hosted:
            candidate_rows = {row['settled_ticks']: row for row in parse_progress(out / 'normalized-hosted-reset-progress.log')}
            comparisons = {}
            for origin, rows in baseline_rows.items():
                common = sorted(set(rows) & set(candidate_rows))
                equal = all(rows[tick] == candidate_rows[tick] for tick in common)
                comparisons[origin] = {'ticks': common, 'equal': equal,
                    'baseline_ticks_not_observed_in_candidate': sorted(set(rows) - set(candidate_rows))}
                assert common and equal, 'normalized observed prefix differs from retained ' + origin
            summary['common_observation_checkpoints'] = {'comparisons_to_retained_baselines': comparisons,
                'boundary': 'Only actual shared receipt-bound checkpoints are compared; unobserved checkpoints and complete-mode termination remain unvalidated.'}
            for name in [NETLIST, CELLS, NETLIST_JSON]:
                assert sha(copied / ('hosted-' + name)) == inventory[name], 'retained hosted copy changed'
        else:
            local_rows = {row['settled_ticks']: row for row in parse_progress(out / 'local-reset-progress.log')}
            hosted_rows = {row['settled_ticks']: row for row in parse_progress(out / 'hosted-reset-progress.log')}
            common = sorted(set(local_rows) & set(hosted_rows))
            summary['common_observation_checkpoints'] = {'ticks': common,
                'equal': all(local_rows[tick] == hosted_rows[tick] for tick in common) if common else None,
                'boundary': 'Observed shared prefix only, not complete validation or scientific acceptance.'}
        assert all(binding(Path(row['path'])) == row for row in original_bindings), 'retained input changed'
        assert all(sha(ROOT / relative) == expected for relative, expected in inputs.items())
        assert source_head() == args.expected_head
        assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT, text=True).strip()
        summary['retained_inputs_and_source_unchanged'] = True
        summary['status'] = 'DIAGNOSTIC_PARTIAL_OBSERVATION_ONLY'
        print('DIAGNOSTIC_PARTIAL superscalar_probe arms=' + str(len(origins)) + ' mode=reset acceptance=0', flush=True)
    except Exception as error:
        summary['status'] = 'DIAGNOSTIC_ERROR_NO_ACCEPTANCE'
        summary['error'] = str(error)
        raise
    finally:
        save(out / 'summary.json', summary)
        save(out / 'artifacts.sha256.json', {str(p.relative_to(out)): sha(p)
            for p in sorted(out.rglob('*')) if p.is_file() and p != out / 'artifacts.sha256.json'})


if __name__ == '__main__':
    main()
