"""Focused input BLAKE2b integration; run only inside one admitted payload."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

source, output = map(Path, sys.argv[1:3])
expected_source = sys.argv[3]
assert subprocess.check_output(['git', '-C', str(source), 'rev-parse', 'HEAD'], text=True).strip() == expected_source
assert not subprocess.check_output(['git', '-C', str(source), 'status', '--porcelain=v1'], text=True).strip()
output.mkdir(parents=True, exist_ok=False)
native_execution = Path('@EXECUTIONS@/20261012T013303Z-848c58102f71')
tool_execution = Path('@EXECUTIONS@/20261016T005835Z-851d576006d4')
library = native_execution / 'build-only/native-build/randomx/librandomx.a'
toolroot = tool_execution / 'output/verilator-5c5314b39cd888f427807d626e1502cbf222c292'
records = []
started = time.monotonic()


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run(label, command):
    row = {'label': label, 'argv': command, 'cwd': str(source)}
    records.append(row)
    (output / 'commands.json').write_text(json.dumps(records, indent=2) + '\n')
    print('START ' + label, flush=True)
    began = time.monotonic()
    with (output / (label + '.log')).open('w') as log:
        result = subprocess.run(['/usr/bin/time', '-v', '-o', str(output / (label + '.time.txt')),
                                 *command], cwd=source, stdout=log, stderr=subprocess.STDOUT)
    row.update(returncode=result.returncode, elapsed_seconds=time.monotonic() - began)
    (output / 'commands.json').write_text(json.dumps(records, indent=2) + '\n')
    result.check_returncode()
    print('PASS ' + label, flush=True)


try:
    run('focused-unit-tests', [sys.executable, '-B', '-m', 'unittest', 'discover', '-s', 'tests',
                               '-p', 'test_lifecycle_*.py', '-v'])
    common = [sys.executable, '-B', str(source / 'scripts/test_prepared_hash_lifecycle.py'),
              '--native-library', str(library), '--native-build-execution', str(native_execution),
              '--hardware-input-hash', '--hardware-fill', '--hardware-program',
              '--programs', '2', '--iterations', '1', '--variants', 'prepared',
              '--event-trace', '--timeout', '3600', '--input-hash-boundaries']
    run('verilator', [*common, '--output', str(output / 'verilator'), '--backend', 'verilator',
                      '--profiles', 'ideal', 'stalled', '--verilator-root', str(toolroot),
                      '--verilator-build-execution', str(tool_execution),
                      '--cancellation', '--cancellation-phases', '8',
                      '--matching-errors', '--error-ports', '7'])
    run('icarus', [*common, '--output', str(output / 'icarus'), '--backend', 'icarus',
                   '--profiles', 'ideal'])
    summaries = {b: json.loads((output / b / 'summary.json').read_text()) for b in ('icarus', 'verilator')}
    for summary in summaries.values():
        assert summary['status'] == 'pass_connected_native_reference'
        assert summary['programs'] == 2 and summary['iterations'] == 1 and not summary['full_v2_requested']
        assert summary['hardware_input_hash'] and summary['hardware_fill'] and summary['hardware_program']
        assert len(summary['input_hash_boundary_checks']) == 1
        boundary = next(iter(summary['input_hash_boundary_checks'].values()))
        checks, provider = boundary['checks'], boundary['host_provider']
        assert checks['prefix_only'] and checks['valid_lengths'] == [0, 80]
        assert checks['valid_seed_prefixes'] == 3 and checks['canceled_input_hashes'] == 1
        assert checks['invalid_lengths'] == [81, 127] and checks['accepted_sram_writes'] == 0
        assert checks['changed_input_successor'] and checks['native_seed_equal'] and checks['removed_provider_drained']
        assert provider['input_hash_calls'] == provider['software_fill_provider_calls'] == 0
        assert provider['program_generations'] == provider['dataset_requests'] == 0
        assert provider['assertion_only_input_hash_calls'] == 4
    ideal = {b: summary['profiles']['prepared-ideal'] for b, summary in summaries.items()}
    assert ideal['icarus']['ledger'] == ideal['verilator']['ledger'], 'complete ideal ledger mismatch'
    assert ideal['icarus']['record'] == ideal['verilator']['record'], 'complete ideal PASS record mismatch'
    for summary in summaries.values():
        for profile in summary['profiles'].values():
            provider, ledger = profile['host_provider'], profile['ledger']
            assert provider['input_hash_calls'] == 0 and provider['input_hash_host_seconds'] == 0
            assert provider['assertion_only_input_hash_calls'] == 1
            assert provider['software_fill_provider_calls'] == provider['program_generations'] == 0
            assert provider['program_generation_host_seconds'] == 0
            assert provider['assertion_only_program_generations'] == 2
            assert ledger['hardware_input_hash_enabled'] and ledger['stage_cycles']['input_hash'] > 0
            assert sum(ledger['nested_input_hash_phases']) == ledger['stage_cycles']['input_hash']
    parity = {'source_commit': expected_source, 'complete_ideal_ledger_equal': True,
              'complete_ideal_pass_record_equal': True, 'files': {}, 'native_corpus': {}}
    for name in ['actual-final-digest32.hex', 'trace.csv']:
        paths = {b: output / b / 'prepared-ideal' / name for b in summaries}
        assert paths['icarus'].read_bytes() == paths['verilator'].read_bytes(), 'backend bytes mismatch: ' + name
        parity['files'][name] = {b: {'sha256': sha(p), 'bytes': p.stat().st_size} for b, p in paths.items()}
    native = {b: {str(p.relative_to(output / b / 'native-reference')): p
                  for p in (output / b / 'native-reference').rglob('*') if p.is_file()} for b in summaries}
    assert set(native['icarus']) == set(native['verilator']) and len(native['icarus']) == 18
    for name, path in native['icarus'].items():
        other = native['verilator'][name]
        assert path.read_bytes() == other.read_bytes(), 'native assertion corpus mismatch: ' + name
        parity['native_corpus'][name] = {'sha256': sha(path), 'bytes': path.stat().st_size}
    assert next(iter(summaries['icarus']['input_hash_boundary_checks'].values()))['record'] == \
           next(iter(summaries['verilator']['input_hash_boundary_checks'].values()))['record']
    assert len(summaries['verilator']['cancellation']) == 1 and len(summaries['verilator']['matching_errors']) == 1
    (output / 'parity-evidence.json').write_text(json.dumps(parity, indent=2) + '\n')
    report = {
        'status': 'pass_bounded_hardware_input_hash_integration', 'source_commit': expected_source,
        'programs': 2, 'iterations_per_program': 1, 'completed_normal_profiles': 3,
        'focused_input_cancellations': 1, 'focused_invalid_length_error_profiles': 1,
        'boundary_prefix_profiles': 2, 'boundary_valid_lengths': [0, 80],
        'boundary_rejected_lengths': [81, 127], 'boundary_accepted_sram_writes': 0,
        'icarus_verilator_complete_ideal_ledger_record_trace_digest_and_native_corpus_equal': True,
        'native_corpus_files_compared': len(native['icarus']),
        'ideal_cycles': ideal['icarus']['ledger']['cycles'],
        'stalled_cycles': summaries['verilator']['profiles']['prepared-stalled']['ledger']['cycles'],
        'ideal_input_hash_cycles': ideal['icarus']['ledger']['stage_cycles']['input_hash'],
        'nested_ideal_input_hash_phases': ideal['icarus']['ledger']['nested_input_hash_phases'],
        'live_input_hash_provider_calls': 0, 'live_fill_provider_calls': 0, 'live_program_provider_calls': 0,
        'normal_assertion_only_input_hash_calls': 1, 'new_default_full_workload': False,
        'boundary': 'Input length0..80 only. The native Light cache/dataset provider and physical device service remain external and untimed. Bounded2x1 integration is not a new default8x2048 result, whole-engine mapping, physical PPA, architecture selection or whole-machine target.',
        'elapsed_seconds': time.monotonic() - started}
    (output / 'checks.json').write_text(json.dumps(report, indent=2, sort_keys=True) + '\n')
    print(json.dumps(report), flush=True)
except Exception as error:
    (output / 'failure.json').write_text(json.dumps({'error': str(error), 'type': type(error).__name__,
                                                    'partial_results_not_passed': True}, indent=2) + '\n')
    raise
