import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
import subprocess
import sys
import time

source, output, expected = Path(sys.argv[1]), Path(sys.argv[2]), sys.argv[3]
output.mkdir(parents=True, exist_ok=False)
started = time.monotonic()
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=source, text=True).strip() == expected
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=source, text=True).strip()

def run(label, args):
    result = subprocess.run(args, cwd=source, capture_output=True, text=True)
    (output / (label + '.log')).write_text(result.stdout + result.stderr)
    assert result.returncode == 0, (label, result.returncode)
    return result.stdout + result.stderr

unit = run('combined-unit', [sys.executable, '-B', '-m', 'unittest', 'discover', '-s', 'tests', '-p', 'test_combined_source_bindings.py', '-v'])
assert 'Ran 18 tests' in unit and '\nOK\n' in unit
run('source-guard', [sys.executable, '-B', 'scripts/combined_source_bindings.py', '--output', str(output / 'binding-report.json')])
report = json.loads((output / 'binding-report.json').read_text())
assert report['status'] == 'pass' and not report['fresh_native_or_hdl_validation_performed']
assert report['original_prepared219_live_bytes_unchanged'] and report['original_regression73_live_bytes_unchanged']
sys.path.insert(0, str(source / 'scripts'))
spec = importlib.util.spec_from_file_location('checked_combined', source / 'scripts/combined_source_bindings.py')
bindings = importlib.util.module_from_spec(spec)
spec.loader.exec_module(bindings)
paths = {bindings.HELPER, bindings.DECLARATION, bindings.OLD_DECLARATION,
         'scripts/prepared_parent_bindings.py', bindings.EXECUTED_FINALIZER[0], *bindings.STAGED}
for relative, _, _ in bindings.MANIFESTS.values():
    paths.add(relative)
    paths.update(json.loads((source / relative).read_text()))
negative = {}
workflow = '.github/workflows/regfile-blake2b.yml'
for label in ('mutated-workflow', 'stale-workflow-declaration'):
    target = output / label
    for relative in paths:
        p = target / relative
        p.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source / relative, p)
    if label == 'mutated-workflow':
        p = target / workflow
        p.write_bytes(p.read_bytes() + b'\n# intentionally mutated negative fixture\n')
    else:
        p = target / bindings.DECLARATION
        value = json.loads(p.read_text())
        value['successors'][workflow]['sha256'] = '0' * 64
        p.write_text(json.dumps(value, indent=2) + '\n')
    try:
        bindings.validate(target)
    except ValueError as error:
        assert str(error) == 'combined live successor changed: ' + workflow, str(error)
        negative[label] = {'rejected': True, 'error': str(error)}
    else:
        raise AssertionError('negative source accepted: ' + label)
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=source, text=True).strip()
checks = {'status': 'pass_staged_workflow_binding_correction', 'source_head': expected,
    'source_tree': subprocess.check_output(['git', 'rev-parse', 'HEAD^{tree}'], cwd=source, text=True).strip(),
    'unit_tests': 18, 'positive_source_guard': True, 'negative_checks': negative,
    'historical_manifests_original_declaration_and_guard_preserved': True,
    'original_prepared219_and_regression73_live_bytes_unchanged': True,
    'workflow_sha256': hashlib.sha256((source / workflow).read_bytes()).hexdigest(),
    'staged_declaration_sha256': hashlib.sha256((source / bindings.DECLARATION).read_bytes()).hexdigest(),
    'fresh_native_hdl_or_synthesis_performed': False, 'elapsed_seconds': time.monotonic() - started}
(output / 'checks.json').write_text(json.dumps(checks, indent=2, sort_keys=True) + '\n')
print(json.dumps(checks), flush=True)
