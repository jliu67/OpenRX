"""Run missing input-boundary/Icarus gates and bind preserved partial results."""
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import time

source, output = map(Path, sys.argv[1:3])
expected_source = sys.argv[3]
old_source = Path('@SOURCE03@')
old_execution = Path('@EXECUTIONS@/20261016T175815Z-3eb05e9e8f2a')
old_output = old_execution / 'output/verilator'
native_execution = Path('@EXECUTIONS@/20261012T013303Z-848c58102f71')
tool_execution = Path('@EXECUTIONS@/20261016T005835Z-851d576006d4')
library = native_execution / 'build-only/native-build/randomx/librandomx.a'
toolroot = tool_execution / 'output/verilator-5c5314b39cd888f427807d626e1502cbf222c292'
output.mkdir(parents=True, exist_ok=False)
records = []
started = time.monotonic()


def sha(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def run(label, command):
    row = {'label': label, 'argv': command, 'cwd': str(source)}
    records.append(row)
    (output / 'commands.json').write_text(json.dumps(records, indent=2) + '\n')
    print('START ' + label, flush=True)
    began = time.monotonic()
    with (output / (label + '.log')).open('w') as log:
        result = subprocess.run(['/usr/bin/time', '-v', '-o', str(output / (label + '.time.txt')),
                                 *command], cwd=source, stdout=log, stderr=subprocess.STDOUT)
    row.update(returncode=result.returncode, elapsed_seconds=time.monotonic() - began)
    (output / 'commands.json').write_text(json.dumps(records, indent=2) + '\n')
    result.check_returncode()
    print('PASS ' + label, flush=True)


try:
    assert subprocess.check_output(['git', '-C', str(source), 'rev-parse', 'HEAD'], text=True).strip() == expected_source
    assert subprocess.check_output(['git', '-C', str(old_source), 'rev-parse', 'HEAD'], text=True).strip() == '307cc9ceef0328021aa7063b0930120b72884099'
    for root in (source, old_source):
        assert not subprocess.check_output(['git', '-C', str(root), 'status', '--porcelain=v1'], text=True).strip()
    changed = subprocess.check_output(['git', '-C', str(source), 'diff', '--name-only',
                                       '307cc9ceef0328021aa7063b0930120b72884099', expected_source], text=True).splitlines()
    bench = 'rtl/hash/tests/tb_prepared_hash_lifecycle.v'
    assert changed == [bench], 'only boundary helper may differ from preserved completed profiles'
    before = (old_source / bench).read_text()
    after = (source / bench).read_text()
    begin, end = ' task input_boundary_case(', ' task check_input_boundaries;'
    a, b = before.index(begin), before.index(end)
    c, d = after.index(begin), after.index(end)
    old_helper, new_helper = before[a:b], after[c:d]
    needle = 'cancel=0;init_rsp_valid=0;init_wr_valid=0;'
    assert old_helper.count(needle) == 2
    assert new_helper == old_helper.replace(needle, needle + '#1;')
    assert before[:a] == after[:c] and before[b:] == after[d:]
    receipt_path = old_execution / 'receipt.json'
    assert sha(receipt_path) == 'b42d8f24954ebcde7b1de4ba82b7fed7173d704510e504994a153e14117e0e19'
    receipt = json.loads(receipt_path.read_text())
    assert receipt['status'] == 'PROCESS_FAILED' and receipt['process']['returncode'] == 1
    artifacts = {Path(row['path']): row for row in receipt['artifacts']}
    used = {}

    def original(path):
        row = artifacts[path]
        assert row['sha256'] == sha(path) and row['bytes'] == path.stat().st_size, str(path)
        used[str(path.relative_to(old_execution))] = {'sha256': row['sha256'], 'bytes': row['bytes']}
        return path

    commands = json.loads(original(old_output / 'commands.json').read_text())
    by_label = {row['label']: row for row in commands}
    assert by_label['prepared-ideal-input-boundaries']['returncode'] == -6
    reused_names = ['prepared-ideal', 'prepared-stalled', 'prepared-stalled-cancel-8', 'prepared-stalled-error-7']
    for name in reused_names:
        assert by_label[name]['returncode'] == 0 and by_label['compile-' + name]['returncode'] == 0
        assert '-GINPUT_HASH_BOUNDARY_TEST=0' in by_label['compile-' + name]['argv']
    sys.path.insert(0, str(source / 'scripts'))
    spec = importlib.util.spec_from_file_location('input_recovery_lifecycle', source / 'scripts/test_prepared_hash_lifecycle.py')
    lifecycle = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(lifecycle)
    native_counts = json.loads(original(old_output / 'native-reference/oracle-summary.json').read_text())

    def pass_record(path, prefix):
        lines = original(path).read_text().splitlines()
        rows = [line for line in lines if line.startswith('PASS ')]
        assert len(rows) == 1 and rows[0].startswith(prefix)
        assert not any('FATAL:' in line or line.startswith('FAIL ') for line in lines)
        return rows[0]

    normal = {}
    for name in reused_names[:2]:
        directory = old_output / name
        ledger = json.loads(original(directory / 'ledger.json').read_text())
        provider = json.loads(original(directory / 'provider-host-time.json').read_text())
        lifecycle.validate_ledger(ledger, provider, 1, 2, native_counts, 1, True, True, True, len(lifecycle.MESSAGE))
        normal[name] = {'ledger': ledger, 'host_provider': provider,
                        'record': pass_record(old_output / (name + '.log'), 'PASS prepared_hash_lifecycle ')}
    controls = {
        'cancel8': pass_record(old_output / 'prepared-stalled-cancel-8.log', 'PASS lifecycle_cancel phase=8 '),
        'error7': pass_record(old_output / 'prepared-stalled-error-7.log', 'PASS lifecycle_matching_error port=7 ')}
    common = [sys.executable, '-B', str(source / 'scripts/test_prepared_hash_lifecycle.py'),
              '--native-library', str(library), '--native-build-execution', str(native_execution),
              '--hardware-input-hash', '--hardware-fill', '--hardware-program', '--programs', '2',
              '--iterations', '1', '--variants', 'prepared', '--event-trace', '--timeout', '3600',
              '--input-hash-boundaries']
    run('verilator-boundaries', [*common, '--output', str(output / 'verilator-boundaries'),
                                '--backend', 'verilator', '--profiles', 'ideal', '--interfaces-only',
                                '--verilator-root', str(toolroot), '--verilator-build-execution', str(tool_execution)])
    run('icarus', [*common, '--output', str(output / 'icarus'), '--backend', 'icarus', '--profiles', 'ideal'])
    new = {name: json.loads((output / name / 'summary.json').read_text()) for name in ('verilator-boundaries', 'icarus')}
    assert new['verilator-boundaries']['status'] == 'pass_lifecycle_interfaces'
    assert not new['verilator-boundaries']['profiles']
    assert new['icarus']['status'] == 'pass_connected_native_reference'
    for summary in new.values():
        assert summary['programs'] == 2 and summary['iterations'] == 1 and not summary['full_v2_requested']
        assert summary['hardware_input_hash'] and summary['hardware_fill'] and summary['hardware_program']
        assert len(summary['input_hash_boundary_checks']) == 1
        boundary = next(iter(summary['input_hash_boundary_checks'].values()))
        checks, provider = boundary['checks'], boundary['host_provider']
        assert checks['prefix_only'] and checks['valid_lengths'] == [0, 80]
        assert checks['valid_seed_prefixes'] == 3 and checks['canceled_input_hashes'] == 1
        assert checks['invalid_lengths'] == [81, 127] and checks['accepted_sram_writes'] == 0
        assert checks['changed_input_successor'] and checks['native_seed_equal'] and checks['removed_provider_drained']
        assert provider['input_hash_calls'] == provider['software_fill_provider_calls'] == provider['program_generations'] == provider['dataset_requests'] == 0
        assert provider['assertion_only_input_hash_calls'] == 4
    ideal = new['icarus']['profiles']['prepared-ideal']
    assert ideal['ledger'] == normal['prepared-ideal']['ledger'], 'complete old-Verilator/new-Icarus ideal ledger mismatch'
    assert ideal['record'] == normal['prepared-ideal']['record'], 'complete ideal PASS record mismatch'
    parity = {'old_execution': old_execution.name, 'old_execution_status_preserved': 'PROCESS_FAILED',
              'old_source': '307cc9ceef0328021aa7063b0930120b72884099', 'recovery_source': expected_source,
              'only_changed_scope': 'Two settle delays in boundary-only helper; original normal/cancel/error flag0 unchanged.',
              'complete_ideal_ledger_equal': True, 'complete_ideal_pass_record_equal': True,
              'files': {}, 'native_corpus': {}}
    for name in ['actual-final-digest32.hex', 'trace.csv']:
        a = original(old_output / 'prepared-ideal' / name)
        b = output / 'icarus/prepared-ideal' / name
        assert a.read_bytes() == b.read_bytes(), 'complete backend bytes mismatch: ' + name
        parity['files'][name] = {'sha256': sha(a), 'bytes': a.stat().st_size}
    golds = {'old-verilator': old_output / 'native-reference',
             **{name: output / name / 'native-reference' for name in new}}
    corpora = {name: {str(p.relative_to(root)): p for p in root.rglob('*') if p.is_file()} for name, root in golds.items()}
    assert all(set(files) == set(corpora['old-verilator']) for files in corpora.values())
    assert len(corpora['old-verilator']) == 18
    for name, path in corpora['old-verilator'].items():
        original(path)
        assert all(path.read_bytes() == files[name].read_bytes() for files in corpora.values()), name
        parity['native_corpus'][name] = {'sha256': sha(path), 'bytes': path.stat().st_size}
    assert next(iter(new['verilator-boundaries']['input_hash_boundary_checks'].values()))['record'] == \
           next(iter(new['icarus']['input_hash_boundary_checks'].values()))['record']
    (output / 'preserved-subresults.json').write_text(json.dumps({'original_receipt_sha256': sha(receipt_path),
        'original_run_stays_failed': True, 'normal_profiles': normal, 'controls': controls,
        'verified_original_artifacts_consumed': used}, indent=2) + '\n')
    (output / 'parity-evidence.json').write_text(json.dumps(parity, indent=2) + '\n')
    report = {'status': 'pass_composite_bounded_hardware_input_hash_integration',
        'original_execution': old_execution.name, 'original_execution_remains_failed': True,
        'original_source': '307cc9ceef0328021aa7063b0930120b72884099', 'recovery_source': expected_source,
        'programs': 2, 'iterations_per_program': 1, 'normal_profiles': 3, 'reused_normal_verilator_profiles': 2,
        'reused_cancel8_profiles': 1, 'reused_error7_profiles': 1, 'new_icarus_normal_profiles': 1,
        'new_boundary_prefix_profiles': 2, 'boundary_valid_lengths': [0, 80], 'boundary_invalid_lengths': [81, 127],
        'native_corpus_files_compared': 18, 'complete_ideal_ledger_record_trace_digest_equal': True,
        'ideal_cycles': ideal['ledger']['cycles'], 'stalled_cycles': normal['prepared-stalled']['ledger']['cycles'],
        'input_hash_cycles': ideal['ledger']['stage_cycles']['input_hash'],
        'nested_input_hash_phases': ideal['ledger']['nested_input_hash_phases'],
        'live_input_hash_fill_program_provider_calls': [0, 0, 0], 'new_default_full_workload': False,
        'remaining_boundary': 'Native Light cache/dataset and physical device service remain external/untimed; no generalinput above80, physical PPA, architecture selection or whole-machine claim.',
        'elapsed_seconds': time.monotonic() - started}
    (output / 'checks.json').write_text(json.dumps(report, indent=2, sort_keys=True) + '\n')
    print(json.dumps(report), flush=True)
except Exception as error:
    (output / 'failure.json').write_text(json.dumps({'error': str(error), 'type': type(error).__name__,
                                                    'partial_results_not_passed': True}, indent=2) + '\n')
    raise
