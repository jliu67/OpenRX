// Compatibility alias: assignments only; sizes belong at module scope.
`include "case_vectors.vh"
